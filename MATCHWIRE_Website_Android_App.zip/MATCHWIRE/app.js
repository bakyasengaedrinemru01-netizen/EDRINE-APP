const matches=[
 {league:'Premier League',home:'Arsenal',away:'Chelsea',score:'2 – 1',state:'Example result · Sample data'},
 {league:'Premier League',home:'Liverpool',away:'Manchester City',score:'1 – 1',state:'Example result · Sample data'},
 {league:'La Liga',home:'Real Madrid',away:'Barcelona',score:'3 – 2',state:'Example result · Sample data'},
 {league:'Champions League',home:'Bayern Munich',away:'PSG',score:'0 – 0',state:'Example score · Sample data'}
];
const fixtures=[
 ['Premier League','Arsenal vs Tottenham','Sample date','15:00'],
 ['La Liga','Barcelona vs Sevilla','Sample date','18:00'],
 ['Champions League','Inter vs Bayern Munich','Sample date','20:00']
];
const standings=[
 ['1','Arsenal','10','+15','25'],['2','Manchester City','10','+12','23'],['3','Liverpool','10','+10','22'],['4','Chelsea','10','+7','19'],['5','Tottenham','10','+5','18']
];
const teams=[['Arsenal','England'],['Chelsea','England'],['Liverpool','England'],['Manchester City','England'],['Manchester United','England'],['Real Madrid','Spain'],['Barcelona','Spain'],['Bayern Munich','Germany'],['PSG','France'],['Inter Milan','Italy']];
const scoreList=document.querySelector('#scoreList');
function renderMatches(filter='All'){scoreList.innerHTML=matches.filter(m=>filter==='All'||m.league===filter).map(m=>`<article class="match-card"><span class="comp">${m.league}</span><span class="match-meta">SAMPLE</span><div class="teams"><span class="club">${m.home}</span><span class="score">${m.score}</span><span class="club">${m.away}</span></div><div class="status">${m.state}</div></article>`).join('')}
renderMatches();
document.querySelectorAll('.filter').forEach(b=>b.addEventListener('click',()=>{document.querySelector('.filter.active').classList.remove('active');b.classList.add('active');renderMatches(b.dataset.filter)}));
document.querySelector('#fixtureRows').innerHTML=fixtures.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join('')}</tr>`).join('');
document.querySelector('#standingRows').innerHTML=standings.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join('')}</tr>`).join('');
function renderTeams(q=''){document.querySelector('#teamList').innerHTML=teams.filter(t=>t[0].toLowerCase().includes(q.toLowerCase())).map(t=>`<div class="team">${t[0]}<small>${t[1]}</small></div>`).join('')||'<p>No teams found.</p>'}
renderTeams();document.querySelector('#teamSearch').addEventListener('input',e=>renderTeams(e.target.value));
document.querySelector('#menuBtn').addEventListener('click',()=>document.querySelector('#nav').classList.toggle('open'));
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./service-worker.js').catch(()=>{}))}
